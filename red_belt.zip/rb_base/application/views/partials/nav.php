<?php ?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Quotable Quotes</a>
    </div>
    <div>
      <ul class="nav navbar-nav">
      	<!-- <li><a href="/main/success">Home</a></li> -->
        <li><a href="/main/destroy">Log Out</a></li>
      </ul>
    </div>
  </div>
</nav>
<?php ?>
